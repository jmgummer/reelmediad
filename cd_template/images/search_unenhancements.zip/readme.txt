Search Unenhancements

There are times when tracking search keywords is undesireable.

Rather than replacing the file:
'/catalog/advanced_search_result.php'

Rename it to:
'/catalog/advanced_search_result_notally.php' and reference it instead.

This is great if you want to embed into a product description a pre-composed search link for other products in a series, or email a pre-composed search link in an email to a client , and don't want the pre-composed search to count in the totals.

Example:
<a href="http://your.website.here/catalog/advanced_search_result.php?keywords=search_term+another_search_term&x=0&y=0" title="Search for other items in the same series">Check out other models in the same series.</a>

Since I employ a standard for naming products, I can search for specific unique phrases, such as "Tele Vue Ethos" without worry of other un-related products appearing in the listing.  To do this, simply separate search words with a plus sign, as in my example.

Perhaps some day I'll generate an add-on to make creating these pre-composed search links easier to author.  There is probably a contribution that presents related or similar products to visitors, but this was quick-and-dirty.

Thanks to everyone involved in Search Enhancements.  I think it's one of the best add-ons, and should be incorporated into the next version.